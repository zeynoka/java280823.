public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        System.out.println("Hello world!");
        System.out.println("Hello world!");
        System.out.println();
        System.out.println("5"+5+"7");
        System.out.println("hello my name is <Adil>");
        System.out.printf("my name is %s,i am %d","Adil",27);
    }
}